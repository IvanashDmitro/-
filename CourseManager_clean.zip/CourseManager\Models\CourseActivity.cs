using System.Text.Json.Serialization;

namespace CourseManager.Models;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "activityType")]
[JsonDerivedType(typeof(LabWork), "LabWork")]
[JsonDerivedType(typeof(Assignment), "Assignment")]
[JsonDerivedType(typeof(Quiz), "Quiz")]
public abstract class CourseActivity : IGradable
{
    private string _title = string.Empty;
    private double _maxScore;
    private DateOnly _deadline;

    protected CourseActivity()
    {
    }

    protected CourseActivity(string title, double maxScore, DateOnly deadline)
    {
        Title = title;
        MaxScore = maxScore;
        Deadline = deadline;
    }

    public string Title
    {
        get => _title;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Назва активності не може бути порожньою.", nameof(value));
            _title = value.Trim();
        }
    }

    public double MaxScore
    {
        get => _maxScore;
        set
        {
            if (value <= 0 || value > 100)
                throw new ArgumentOutOfRangeException(nameof(value), "Максимальний бал має бути в межах від 1 до 100.");
            _maxScore = value;
        }
    }

    public DateOnly Deadline
    {
        get => _deadline;
        set
        {
            if (value.Year < 2020 || value.Year > 2035)
                throw new ArgumentOutOfRangeException(nameof(value), "Некоректна дата дедлайну.");
            _deadline = value;
        }
    }

    public abstract string TypeName { get; }

    public abstract double CalculateScore(double rawScore, bool isLate);

    // Так робота виглядає у випадаючому списку: «Лабораторна 2 (макс. 15)».
    public override string ToString() => $"{Title} (макс. {MaxScore})";

    protected void ValidateRawScore(double rawScore)
    {
        if (rawScore < 0 || rawScore > MaxScore)
            throw new ArgumentOutOfRangeException(nameof(rawScore),
                $"Оцінка {rawScore} виходить за межі [0; {MaxScore}].");
    }
}
