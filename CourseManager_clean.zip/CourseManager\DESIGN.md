# Специфікація проєкту «Система управління навчальними курсами»

## 1. Архітектура MVVM
- `Models/` – інтерфейс `IGradable`, абстрактний клас `CourseActivity`, спадкоємці `LabWork`, `Assignment`, `Quiz` з поліморфним методом `CalculateScore()`, класи `Course`, `Student`, `GradeRecord`, `Enrollment`, `StorageData`, `BenchmarkResult`.
- `Services/` – `CourseService` (CRUD, валідація, перевірка повторного запису, розрахунок рейтингу `T1`/`Tn` із `lock` та `CancellationToken`), `DataGenerator`.
- `Repositories/` – `JsonStorage` (атомарне збереження та прив'язка посилань `ValidateAndLink()`), `XmlReportExporter`.
- `ViewModels/` – `MainWindowViewModel` (команди `CommunityToolkit.Mvvm`, пошук, фільтрація, сортування, фонові операції).
- `Views/` – `MainWindow.axaml` (інтерфейс із `DataGrid`, формою CRUD та `ProgressBar`), `ConfirmDialog` (вікно підтвердження «Так / Скасувати», передається у ViewModel через властивість `Confirm`).

## 2. UML-діаграма класів (Mermaid)
```mermaid
classDiagram
    class IGradable {
        <<interface>>
        +MaxScore : double
        +CalculateScore(rawScore: double, isLate: bool) double
    }
    class CourseActivity {
        <<abstract>>
        +Title : string
        +MaxScore : double
        +Deadline : DateOnly
        +TypeName : string
        +CalculateScore(rawScore: double, isLate: bool) double
    }
    class LabWork {
        +DefenseBonus : int
        +CalculateScore(rawScore: double, isLate: bool) double
    }
    class Assignment {
        +LatePenaltyRate : double
        +CalculateScore(rawScore: double, isLate: bool) double
    }
    class Quiz {
        +QuestionsCount : int
        +CalculateScore(rawScore: double, isLate: bool) double
    }
    class Course {
        +Code : string
        +Title : string
        +Instructor : string
        +Activities : List~CourseActivity~
        +AddStandardActivities(start: DateOnly)
    }
    class Student {
        +FullName : string
        +Group : string
    }
    class GradeRecord {
        +Activity : CourseActivity
        +RawScore : double
        +IsLate : bool
        +FinalScore : double
    }
    class Enrollment {
        +Student : Student
        +Course : Course
        +Grades : List~GradeRecord~
        +TotalRating : double
        +NationalGrade : string
        +NextActivity : CourseActivity
        +NextDeadline : DateOnly
        +FindGrade(activity: CourseActivity) GradeRecord
    }
    class CourseService {
        +AddCourse(course: Course)
        +AddStudent(student: Student)
        +EnrollStudent(student: Student, course: Course) Enrollment
        +AddGrade(enrollment: Enrollment, activity: CourseActivity, rawScore: double, isLate: bool) bool
        +CalculateRatingsSequential(token: CancellationToken) Dictionary
        +CalculateRatingsBenchmarkAsync(progress: IProgress, token: CancellationToken) Task~BenchmarkResult~
    }

    IGradable <|.. CourseActivity
    CourseActivity <|-- LabWork
    CourseActivity <|-- Assignment
    CourseActivity <|-- Quiz
    Course "1" *-- "0..*" CourseActivity
    Enrollment "0..1" --> "1" Student
    Enrollment "0..*" --> "1" Course
    Enrollment "1" *-- "0..*" GradeRecord
    GradeRecord "0..*" --> "1" CourseActivity
    CourseService --> Enrollment
```

## 3. Ключові алгоритми (для блок-схем за ДСТУ ISO 5807:2016)
1. **Розрахунок рейтингу частинами (`CalculateRatingsBenchmarkAsync`)**: зняття знімка записів разом із копіями масивів оцінок під `lock` (зміни в інтерфейсі під час розрахунку не зачіпають знімок) → прогрів обох варіантів без заміру (JIT і пул потоків) → три однопотокові заміри, у `T1` береться найкращий → розбиття знімка на частини за кількістю ядер → паралельний запуск `Task.Run` із перевіркою `CancellationToken`, три заміри, у `Tn` найкращий → об'єднання локальних словників під `lock` → оновлення `IProgress<double>` після кожного кроку → обчислення прискорення `S = T1 / Tn`. Для чесних замірів методи розрахунку позначено `[MethodImpl(MethodImplOptions.AggressiveOptimization)]`: вони одразу компілюються оптимізовано, а решта програми стартує швидко.
2. **Перевірка запису на курс (`EnrollStudent`)**: перевірка аргументів на `null` → вхід у критичну секцію `lock` → пошук у `_enrollments` запису цього здобувача (ПІБ + група, без урахування регістру) → якщо запис є і курс той самий, `InvalidOperationException` «Повторний запис заборонено» → якщо запис є на іншому курсі, `InvalidOperationException` «здобувач може бути записаний лише на один курс» → інакше створення `Enrollment` і додавання до списку.

## 4. Правила предметної області
- Кожен курс оцінюється за 100-бальною шкалою: 4 лабораторні по 15 балів, 2 практичні по 10, 2 тести по 10 (`Course.AddStandardActivities()`).
- За кожну роботу в записі зберігається одна оцінка; повторне виставлення замінює попередню (`CourseService.AddGrade()`), тому рейтинг не перевищує 100.
- Переведення в національну шкалу (`Enrollment.NationalGrade`): 90–100 «відмінно», 74–89 «добре», 60–73 «задовільно», менше 60 «незадовільно».
- Один здобувач записаний лише на один курс (`CourseService.EnrollStudent()`, перевірка при імпорті в `JsonStorage.ValidateAndLink()`).
- Наступна робота (`Enrollment.NextActivity`) – робота курсу з найранішим дедлайном, за яку ще немає оцінки. Таблиця показує її назву і дедлайн (з позначкою «простр.», якщо дата минула), сортування «Наступний дедлайн» ставить угору найстаріші борги, фільтр відбирає записи за типом наступної роботи або «Усе здано».
- Підрахунок балів: лабораторна – бал + бонус за захист (лише якщо бал більший за 0), при запізненні 85 % без бонусу; практична – мінус `LatePenaltyRate` при запізненні; тест – бал округлюється вниз до цілої кількості правильних відповідей (`MaxScore / QuestionsCount` за питання), при запізненні 70 %. Підсумок роботи не перевищує її максимум.
- Видалення курсу, здобувача, запису, імпорт JSON і генерація великого набору виконуються лише після підтвердження в `ConfirmDialog`.
- «Експорт JSON» зберігає дані у файл, вказаний у полі шляху (те саме поле використовує імпорт). Після успішного імпорту чи генерації дані одразу зберігаються в `courses.json`; при помилці імпорту поточні дані не змінюються.
- Під час імпорту `JsonStorage.ValidateAndLink()` відхиляє файли з повторними кодами курсів, повторними здобувачами, двома курсами в одного здобувача, двома оцінками за ту саму роботу та балами поза межами.
- Оновлення курсу чи здобувача спершу перевіряє всі нові значення, тому при помилці запис не змінюється частково. Код курсу не змінюється.
- Якщо в полях введено ПІБ чи код, дії виконуються саме для введеного здобувача / курсу, а не для вибраного у списку.
- Клік по рядку таблиці обирає його здобувача і курс у правій панелі (поля заповнюються), тож одразу можна натиснути «Оновити». `Student` і `Course` реалізують `INotifyPropertyChanged`, тому нові ПІБ, група чи назва курсу одразу видно в таблиці та випадних списках.
- Фільтр груп будується з наявних даних (нова група одразу з'являється у списку). Таблиця показує до 500 рядків, лічильник унизу повідомляє «Показано 500 з N».
- XML-відомість (`course_grade_sheet.xml`) згрупована за курсами; у кожному курсі здобувачі відсортовані за спаданням рейтингу, для кожного вказано групу, рейтинг і оцінку за національною шкалою.
- Стартовий набір: 100 здобувачів (по 25 у групах 3РП-11, 2РП-12, 3КІ-21, 2КІ-22, по 20 на кожному з 5 курсів), частина робіт слабших здобувачів ще не оцінена. Великий набір для замірів T1/Tn: рівно 15 000 оцінок; частина здобувачів теж має борги, тому здобувачів близько 2090 (`DataGenerator.Generate()` додає їх, доки не набереться потрібна кількість оцінок). Кнопка «Стартовий набір» (`DataGenerator.GenerateStartSet()`) повертає 100 здобувачів.
