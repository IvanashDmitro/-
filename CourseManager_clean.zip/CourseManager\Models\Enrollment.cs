using System.Text.Json.Serialization;

namespace CourseManager.Models;

public sealed class Enrollment
{
    private Student _student = null!;
    private Course _course = null!;

    public Enrollment()
    {
    }

    public Enrollment(Student student, Course course)
    {
        Student = student;
        Course = course;
    }

    public Student Student
    {
        get => _student;
        set => _student = value ?? throw new ArgumentNullException(nameof(value));
    }

    public Course Course
    {
        get => _course;
        set => _course = value ?? throw new ArgumentNullException(nameof(value));
    }

    public List<GradeRecord> Grades { get; set; } = new();

    // Обчислювані властивості не зберігаються в JSON, а рахуються з оцінок після завантаження.

    // Рейтинг за 100-бальною шкалою: сума балів за всі роботи курсу (максимум 100).
    [JsonIgnore]
    public double TotalRating => Math.Round(Grades.Sum(g => g.FinalScore), 2);

    // Переведення рейтингу в національну шкалу.
    [JsonIgnore]
    public string NationalGrade => ToNationalGrade(TotalRating);

    public static string ToNationalGrade(double rating) => rating switch
    {
        >= 90 => "Відмінно",
        >= 74 => "Добре",
        >= 60 => "Задовільно",
        _ => "Незадовільно"
    };

    public GradeRecord? FindGrade(CourseActivity activity) =>
        Grades.FirstOrDefault(g => g.Activity.Title.Equals(activity.Title, StringComparison.OrdinalIgnoreCase));

    // Наступна невиконана робота: найраніший дедлайн серед робіт курсу, за які ще немає оцінки.
    [JsonIgnore]
    public CourseActivity? NextActivity =>
        Course.Activities
            .Where(a => FindGrade(a) == null)
            .OrderBy(a => a.Deadline)
            .FirstOrDefault();

    // Для сортування: у кого все здано, той опиняється в кінці списку.
    [JsonIgnore]
    public DateOnly NextDeadline => NextActivity?.Deadline ?? DateOnly.MaxValue;

    [JsonIgnore]
    public string NextActivityText => NextActivity?.Title ?? "Усе здано";

    [JsonIgnore]
    public string NextActivityType => NextActivity?.TypeName ?? "Усе здано";

    [JsonIgnore]
    public string NextDeadlineText
    {
        get
        {
            var next = NextActivity;
            if (next == null)
                return "–";
            bool overdue = next.Deadline < DateOnly.FromDateTime(DateTime.Today);
            return next.Deadline.ToString("dd.MM.yyyy") + (overdue ? " (простр.)" : "");
        }
    }
}
