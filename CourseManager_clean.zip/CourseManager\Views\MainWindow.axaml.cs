using Avalonia.Controls;
using CourseManager.ViewModels;

namespace CourseManager.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    // ViewModel не знає про вікна, тому показ діалогу підтвердження передається їй звідси.
    protected override void OnDataContextChanged(EventArgs e)
    {
        base.OnDataContextChanged(e);
        if (DataContext is MainWindowViewModel vm)
            vm.Confirm = message => ConfirmDialog.ShowAsync(this, message);
    }
}
